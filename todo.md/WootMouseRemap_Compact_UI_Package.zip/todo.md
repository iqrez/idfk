# See previous instructions in chat; integrate src_additions and wire navigation + RawInput.
